(() => {
  'use strict';
  const gallery = document.querySelector('#card-gallery');
  const dialog = document.querySelector('#card-dialog');
  let selectedSet = '0';
  let lastCard;
  const setNames = {'0':'最初的记忆','1':'字母集','2':'《MIU》登场角色','4':'大阿卡纳'};
  function showDetails(card, trigger) {
    lastCard = trigger;
    document.querySelector('#dialog-image').src = card.image;
    document.querySelector('#dialog-image').alt = card.name + '卡面';
    document.querySelector('#dialog-title').textContent = card.name;
    document.querySelector('#dialog-description').textContent = card.description;
    document.querySelector('#dialog-set').textContent = setNames[card.set] + ' / 记忆碎片';
    dialog.showModal();
  }
  function render() {
    const cards = window.PROMO_CARDS.filter(card => card.set === selectedSet);
    gallery.replaceChildren();
    cards.forEach((card, i) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'gallery-card';
      button.setAttribute('aria-label', '查看' + card.name + '的记忆');
      const image = document.createElement('img');
      image.src = card.image;
      image.alt = card.name;
      image.loading = 'lazy';
      image.width = 200;
      image.height = 280;
      const label = document.createElement('span');
      label.className = 'card-label';
      const name = document.createElement('strong');
      name.textContent = card.name;
      const index = document.createElement('small');
      index.textContent = String(i + 1).padStart(2, '0');
      label.append(name, index);
      button.append(image, label);
      button.addEventListener('click', () => showDetails(card, button));
      gallery.append(button);
    });
    document.querySelector('#gallery-status').textContent = setNames[selectedSet] + ' · 共 ' + cards.length + ' 张记忆';
  }
  document.querySelectorAll('[data-set]').forEach(button => button.addEventListener('click', () => {
    selectedSet = button.dataset.set;
    document.querySelectorAll('[data-set]').forEach(item => {
      const active = item === button;
      item.classList.toggle('active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    render();
  }));
  document.querySelector('#foil-toggle').addEventListener('click', event => {
    const active = gallery.classList.toggle('foil');
    event.currentTarget.setAttribute('aria-pressed', String(active));
    event.currentTarget.textContent = active ? '✦ 关闭镭射预览' : '✦ 镭射光泽预览';
  });
  document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    const box = dialog.getBoundingClientRect();
    if (event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom)) dialog.close();
  });
  dialog.addEventListener('close', () => lastCard?.focus());
  render();
})();
