window.PROMO_CARDS = [
    {
        "name":  "空白",
        "set":  "0",
        "description":  "这是还没被记住的部分。不是遗忘，而是尚未发生。所有记忆，都是从这里开始偏移的",
        "image":  "assets/card-0.png"
    },
    {
        "name":  "起始",
        "set":  "0",
        "description":  "某个瞬间突然被固定下来。在那之前，一切都是流动的。这是你开始“记住”的证据",
        "image":  "assets/card-1.png"
    },
    {
        "name":  "分岔",
        "set":  "0",
        "description":  "记忆开始有了对照。你意识到事情并不只有一种样子。但你只能带走其中之一",
        "image":  "assets/card-2.png"
    },
    {
        "name":  "成形",
        "set":  "0",
        "description":  "三个碎片彼此支撑，勉强构成一个可以被理解的轮廓。你开始相信，这是真的发生过的事",
        "image":  "assets/card-3.png"
    },
    {
        "name":  "规则",
        "set":  "0",
        "description":  "为了不让记忆崩塌，你给它加上边界、顺序和名字。世界从这里开始变得沉重",
        "image":  "assets/card-4.png"
    },
    {
        "name":  "停留",
        "set":  "0",
        "description":  "这是你停下来回头看的位置。不是最早，也不是最晚。只是刚好还能记得清楚",
        "image":  "assets/card-5.png"
    },
    {
        "name":  "重复",
        "set":  "0",
        "description":  "有些记忆并没有新的内容，只是一次又一次被拿出来确认。你分不清是在回忆，还是在维持",
        "image":  "assets/card-6.png"
    },
    {
        "name":  "极限",
        "set":  "0",
        "description":  "这是你所能承载的上限。再多一点，形状就会开始崩坏。于是你选择放手",
        "image":  "assets/card-7.png"
    },
    {
        "name":  "回响",
        "set":  "0",
        "description":  "记忆已经不再属于当下，却仍在结构中反复震动。世界记得你来过",
        "image":  "assets/card-8.png"
    },
    {
        "name":  "残留",
        "set":  "0",
        "description":  "这是被保存下来的最后一部分。不完整，但足够被命名。下一次，你会从零开始",
        "image":  "assets/card-9.png"
    },
    {
        "name":  "偶数",
        "set":  "0",
        "description":  "可以被平均分开的数字。在拆分之后，一切都刚刚好",
        "image":  "assets/card-10.png"
    },
    {
        "name":  "奇数",
        "set":  "0",
        "description":  "无法被平均分开的数字。在拆分之后，总会留下些什么",
        "image":  "assets/card-11.png"
    },
    {
        "name":  "字母A",
        "set":  "1",
        "description":  "A 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-12.png"
    },
    {
        "name":  "字母B",
        "set":  "1",
        "description":  "B 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-13.png"
    },
    {
        "name":  "字母C",
        "set":  "1",
        "description":  "C 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-14.png"
    },
    {
        "name":  "字母D",
        "set":  "1",
        "description":  "D 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-15.png"
    },
    {
        "name":  "字母E",
        "set":  "1",
        "description":  "E 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-16.png"
    },
    {
        "name":  "字母F",
        "set":  "1",
        "description":  "F 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-17.png"
    },
    {
        "name":  "字母G",
        "set":  "1",
        "description":  "G 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-18.png"
    },
    {
        "name":  "字母H",
        "set":  "1",
        "description":  "H 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-19.png"
    },
    {
        "name":  "字母I",
        "set":  "1",
        "description":  "I 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-20.png"
    },
    {
        "name":  "字母J",
        "set":  "1",
        "description":  "G 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-21.png"
    },
    {
        "name":  "字母K",
        "set":  "1",
        "description":  "K 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-22.png"
    },
    {
        "name":  "字母L",
        "set":  "1",
        "description":  "L 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-23.png"
    },
    {
        "name":  "字母M",
        "set":  "1",
        "description":  "M 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-24.png"
    },
    {
        "name":  "字母N",
        "set":  "1",
        "description":  "N 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-25.png"
    },
    {
        "name":  "字母O",
        "set":  "1",
        "description":  "O 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-26.png"
    },
    {
        "name":  "字母P",
        "set":  "1",
        "description":  "P 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-27.png"
    },
    {
        "name":  "字母Q",
        "set":  "1",
        "description":  "Q 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-28.png"
    },
    {
        "name":  "字母R",
        "set":  "1",
        "description":  "R 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-29.png"
    },
    {
        "name":  "字母S",
        "set":  "1",
        "description":  "S 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-30.png"
    },
    {
        "name":  "字母T",
        "set":  "1",
        "description":  "T 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-31.png"
    },
    {
        "name":  "字母U",
        "set":  "1",
        "description":  "U 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-32.png"
    },
    {
        "name":  "字母V",
        "set":  "1",
        "description":  "V 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-33.png"
    },
    {
        "name":  "字母W",
        "set":  "1",
        "description":  "W 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-34.png"
    },
    {
        "name":  "字母X",
        "set":  "1",
        "description":  "X 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-35.png"
    },
    {
        "name":  "字母Y",
        "set":  "1",
        "description":  "Y 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-36.png"
    },
    {
        "name":  "字母Z",
        "set":  "1",
        "description":  "Z 是一个字母，本身没有意义，但可以被反复用来指代某个位置或名字",
        "image":  "assets/card-37.png"
    },
    {
        "name":  "小太刀",
        "set":  "2",
        "description":  "游戏《MIU》中出场的角色",
        "image":  "assets/card-38.png"
    },
    {
        "name":  "夜光游水母",
        "set":  "2",
        "description":  "游戏《MIU》中出场的角色",
        "image":  "assets/card-39.png"
    },
    {
        "name":  "勿一",
        "set":  "2",
        "description":  "游戏《MIU》中出场的角色",
        "image":  "assets/card-40.png"
    },
    {
        "name":  "她",
        "set":  "2",
        "description":  "游戏《MIU》中出场的角色",
        "image":  "assets/card-41.png"
    },
    {
        "name":  "愚者",
        "set":  "4",
        "description":  "背起尚未命名的记忆，向第一步出发。",
        "image":  "assets/card-43.png"
    },
    {
        "name":  "魔术师",
        "set":  "4",
        "description":  "散落的碎片，在指尖找到形状。",
        "image":  "assets/card-44.png"
    },
    {
        "name":  "女祭司",
        "set":  "4",
        "description":  "有些答案藏在未被翻开的那一页。",
        "image":  "assets/card-45.png"
    },
    {
        "name":  "皇后",
        "set":  "4",
        "description":  "让一段记忆有地方生长。",
        "image":  "assets/card-46.png"
    },
    {
        "name":  "皇帝",
        "set":  "4",
        "description":  "替摇晃的世界立下一道边界。",
        "image":  "assets/card-47.png"
    },
    {
        "name":  "教皇",
        "set":  "4",
        "description":  "沿着前人的回响，记住来时的路。",
        "image":  "assets/card-48.png"
    },
    {
        "name":  "恋人",
        "set":  "4",
        "description":  "两段记忆相遇，也带来了选择。",
        "image":  "assets/card-49.png"
    },
    {
        "name":  "战车",
        "set":  "4",
        "description":  "带上犹豫，仍向远处行进。",
        "image":  "assets/card-50.png"
    },
    {
        "name":  "力量",
        "set":  "4",
        "description":  "轻轻握住那份不肯平息的心情。",
        "image":  "assets/card-51.png"
    },
    {
        "name":  "隐者",
        "set":  "4",
        "description":  "借一盏微光，照见自己的来路。",
        "image":  "assets/card-52.png"
    },
    {
        "name":  "命运之轮",
        "set":  "4",
        "description":  "有些告别，会在下一圈重新相逢。",
        "image":  "assets/card-53.png"
    },
    {
        "name":  "正义",
        "set":  "4",
        "description":  "把留下与失去，都放在天平上。",
        "image":  "assets/card-54.png"
    },
    {
        "name":  "倒吊人",
        "set":  "4",
        "description":  "换一个方向，看那些熟悉的形状。",
        "image":  "assets/card-55.png"
    },
    {
        "name":  "死神",
        "set":  "4",
        "description":  "旧的形状散去，新的记忆才能落下。",
        "image":  "assets/card-56.png"
    },
    {
        "name":  "节制",
        "set":  "4",
        "description":  "让不同的碎片，慢慢找到彼此的位置。",
        "image":  "assets/card-57.png"
    },
    {
        "name":  "恶魔",
        "set":  "4",
        "description":  "你握紧的东西，也可能握紧了你。",
        "image":  "assets/card-58.png"
    },
    {
        "name":  "高塔",
        "set":  "4",
        "description":  "当边界碎裂，仍有一小片真实留下。",
        "image":  "assets/card-59.png"
    },
    {
        "name":  "星星",
        "set":  "4",
        "description":  "远处的微光，记得为你留着。",
        "image":  "assets/card-60.png"
    },
    {
        "name":  "月亮",
        "set":  "4",
        "description":  "沿着倒影行走，先别急着命名。",
        "image":  "assets/card-61.png"
    },
    {
        "name":  "太阳",
        "set":  "4",
        "description":  "那些模糊的片段，终于被照亮。",
        "image":  "assets/card-62.png"
    },
    {
        "name":  "审判",
        "set":  "4",
        "description":  "听见自己的名字，从旧日深处传来。",
        "image":  "assets/card-63.png"
    },
    {
        "name":  "世界",
        "set":  "4",
        "description":  "所有走过的路，在这里围成一个圆。",
        "image":  "assets/card-64.png"
    }
];